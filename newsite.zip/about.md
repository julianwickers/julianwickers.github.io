---
layout: page
title: About
permalink: /about/
---

Amish Habits is about improving your miserable life with a radical philosophy that mixes late night infomercials with ancient Amish wisdom.  You CAN get rich quick, you CAN lose weight fast, and you can do it with little or no effort.  I will show you how.

Hi, I’m Julian Wickers, and I’m passionate about teaching morons how to improve their lives.  I want YOU to become rich and successful, just like me.

#### About Me ####

I live in Boulder Colorado, where I spend my days writing, meditating, parenting, and doing CROSSFIT, the one true exercise.  I eat a paleo vegan diet and do my best to be gluten and crouton free.  I practice my minimalist lifestyle in an enormous suburban mansion, along with my super hot wife and our two kids.

If you’re still curious, check out [Who is Julian Wickers]({{site.posts[0].url}})

#### Contact ####

<p class="well">
Julian @[AmishHabits.com]
</p>